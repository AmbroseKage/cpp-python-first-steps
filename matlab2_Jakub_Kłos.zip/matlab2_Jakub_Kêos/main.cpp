#include "matlab.hpp"

#include <cstdlib>

int main() {
    return EXIT_SUCCESS;
}
